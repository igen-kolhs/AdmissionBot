Please run :

pip install fuzzywuzzy
pip install nltk 

before running the AdmissionTard.py file.