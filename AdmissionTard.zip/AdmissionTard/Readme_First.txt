Note : For using the chatbot, Please download the zip.

Please run setup.bat before running the AdmissionTard.py