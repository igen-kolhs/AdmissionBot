Please run these commands in command prompt before running the AdmissionBot.py file :

python -m pip install fuzzywuzzy
python -m pip install nltk
python -m pip install levenshtein 


for running it in command prompt :
1. Right click on the folder (where python file and database file is stored) and click open with command prompt 
2. run the python file using the command : python "pythonfilename.py" (remove the " ")

for running it in an idle :
1. open the folder where the file is stored
2. run the python file

Note - Please verify that the python file and database file are in the same folder/subfolder for running the bot properly.